package com.example.timetrackpro;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;

public class PieChartActivity extends AppCompatActivity {

    PieChart pieChart;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piechart);

        pieChart = findViewById(R.id.pieChart);
        db = new DatabaseHelper(this);

        ArrayList<PieEntry> entries = new ArrayList<>();

        // ✅ correct method
        Cursor cursor = db.getTotalTimeByActivity();

        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            int total = cursor.getInt(1);
            entries.add(new PieEntry(total, name));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Minutes");
        PieData data = new PieData(dataSet);

        pieChart.setData(data);
        pieChart.invalidate();
    }
}
