package com.example.timetrackpro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivityActivity extends AppCompatActivity {

    EditText etName, etMinutes;
    Button btnSave;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_activity);

        etName = findViewById(R.id.etName);
        etMinutes = findViewById(R.id.etMinutes);
        btnSave = findViewById(R.id.btnSave);

        db = new DatabaseHelper(this);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String minStr = etMinutes.getText().toString().trim();

            if (name.isEmpty() || minStr.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int minutes = Integer.parseInt(minStr);

            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            db.insertActivity(name, minutes, date);
            Toast.makeText(this, "Saved ✅", Toast.LENGTH_SHORT).show();

            etName.setText("");
            etMinutes.setText("");
        });
    }
}
