package com.example.timetrackpro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // ✅ Database Info
    private static final String DB_NAME = "timetrack.db";
    private static final int DB_VERSION = 2; // ✅ IMPORTANT: set 2 (because we added users table)

    // ✅ Activities Table
    public static final String TABLE_NAME = "activities";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_MINUTES = "minutes";
    public static final String COL_DATE = "date";

    // ✅ Users Table
    public static final String USER_TABLE = "users";
    public static final String U_ID = "uid";
    public static final String U_NAME = "name";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // ✅ Create Activities Table
        String createActivities = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_MINUTES + " INTEGER, " +
                COL_DATE + " TEXT" +
                ")";
        db.execSQL(createActivities);

        // ✅ Create Users Table
        String createUsers = "CREATE TABLE " + USER_TABLE + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                U_NAME + " TEXT, " +
                U_USERNAME + " TEXT UNIQUE, " +
                U_PASSWORD + " TEXT" +
                ")";
        db.execSQL(createUsers);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // ✅ Drop old tables then create again
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        onCreate(db);
    }

    // ======================================================
    // ✅ ACTIVITY METHODS (Sleep / Study / Exercise etc)
    // ======================================================

    // ✅ Insert activity record
    public void insertActivity(String name, int minutes, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        cv.put(COL_MINUTES, minutes);
        cv.put(COL_DATE, date);

        db.insert(TABLE_NAME, null, cv);
        db.close();
    }

    // ✅ Used for Pie Chart: total minutes grouped by activity
    public Cursor getTotalTimeByActivity() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT " + COL_NAME + ", SUM(" + COL_MINUTES + ") as total " +
                        "FROM " + TABLE_NAME + " GROUP BY " + COL_NAME,
                null
        );
    }

    // ======================================================
    // ✅ USER METHODS (Register/Login)
    // ======================================================

    // ✅ Register new user
    public boolean registerUser(String name, String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(U_NAME, name);
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);

        long result = db.insert(USER_TABLE, null, cv);
        db.close();

        return result != -1;
    }

    // ✅ Check username already exists or not
    public boolean isUserExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USER_TABLE + " WHERE " + U_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return exists;
    }

    // ✅ Login user
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USER_TABLE + " WHERE " + U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean success = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return success;
    }
}
