package com.example.timetrackpro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnAddActivity, btnStudyStopwatch, btnSleep, btnUsage, btnCalendar, btnChart, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ✅ Connect buttons
        btnAddActivity = findViewById(R.id.btnAddActivity);
        btnStudyStopwatch = findViewById(R.id.btnStudyStopwatch);
        btnSleep = findViewById(R.id.btnSleep);
        btnUsage = findViewById(R.id.btnUsage);
        btnCalendar = findViewById(R.id.btnCalendar);
        btnChart = findViewById(R.id.btnChart);
        btnLogout = findViewById(R.id.btnLogout);

        // ✅ Open Add Activity screen
        btnAddActivity.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddActivityActivity.class))
        );

        // ✅ Open Stopwatch screen (Study Stopwatch)
        btnStudyStopwatch.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, StopwatchActivity.class))
        );

        // ✅ Open Sleep Tracker
        btnSleep.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SleepTrackerActivity.class))
        );

        // ✅ Open Screen Time + App Usage
        btnUsage.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AppUsageActivity.class))
        );

        // ✅ Open Calendar
        btnCalendar.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, CalendarActivity.class))
        );

        // ✅ Open Pie Chart Report
        btnChart.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, PieChartActivity.class))
        );

        // ✅ Logout function
        btnLogout.setOnClickListener(v -> {
            // Clear login session
            getSharedPreferences("login", MODE_PRIVATE)
                    .edit()
                    .clear()
                    .apply();

            // Send user back to Login page
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        });
    }
}
