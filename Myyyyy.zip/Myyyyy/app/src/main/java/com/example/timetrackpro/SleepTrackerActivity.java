package com.example.timetrackpro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SleepTrackerActivity extends AppCompatActivity {

    EditText etSleepHours;
    Button btnSaveSleep;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_tracker);

        etSleepHours = findViewById(R.id.etSleepHours);
        btnSaveSleep = findViewById(R.id.btnSaveSleep);

        db = new DatabaseHelper(this);

        btnSaveSleep.setOnClickListener(v -> {
            String hoursStr = etSleepHours.getText().toString().trim();

            if (hoursStr.isEmpty()) {
                Toast.makeText(this, "Please enter sleep hours", Toast.LENGTH_SHORT).show();
                return;
            }

            double hours = Double.parseDouble(hoursStr);

            int minutes = (int) (hours * 60);

            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            db.insertActivity("Sleep", minutes, date);
            Toast.makeText(this, "Sleep saved ✅ (" + minutes + " min)", Toast.LENGTH_SHORT).show();

            etSleepHours.setText("");
        });
    }
}
